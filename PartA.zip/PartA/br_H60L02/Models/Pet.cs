﻿using System;
using System.Collections.Generic;

namespace br_H60L02.Models;

public partial class Pet
{
    public decimal PetId { get; set; }

    public string? PetName { get; set; }
}
