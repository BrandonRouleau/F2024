[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/DxCRGnVi)
# 420-H60-HR Lab 2b
Refactor this project to respect the Single Responsibility Principle.
Update the word document for this lab with your answers
