﻿

using System;

namespace ConsoleUI
{
    class Program
    {

        // Analyze this class for Single Responsibility Principle violations and fix it
        // What is the purpose of the Main?
        // Consider what would have to change if you wanted to change:
        // UI behaviours, greetings, input prompts, or changes to the Person class
        static void Main(string[] args)
        {
            Validate validate = new Validate();
            Writer writer = new Writer();
            Reader reader = new Reader();
            writer.welcome();

            //Ask for user information
            Person user = new Person();

            writer.firstName();
            user.FirstName = reader.ReadLine();

            writer.lastName();
            user.LastName = reader.ReadLine();

            //check to be sure the first and last name is valid
            // Checks to be sure the first and last names are valid
            if (validate.validateFirstName(user.FirstName))
            {
                writer.invalidFirstName();
                reader.ReadLine();
                return;  // exit early
            }

            if (validate.validateLastName(user.LastName))
            {
                writer.invalidLasName();
                reader.ReadLine();
                return;  // exit early
            }

            // Create a username for the person (just fake/simulate it)
            writer.userName(user);

            reader.ReadLine(); // pause before bye bye

            return;
        }
    }
}
