﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI {
    internal class Writer {
        public void welcome() {
            Console.WriteLine("Welcome to my application!");
        }

        public void firstName() {
            Console.WriteLine("What is your first name: ");
        }

        public void lastName() {
            Console.WriteLine("What is your last name: ");
        }

        public void invalidFirstName() {
            Console.WriteLine("You did not give us a valid first name! ");
        }

        public void invalidLasName() {
            Console.WriteLine("You did not give us a valid last name! ");
        }

        public void userName(Person user) {
            Console.WriteLine($"Your username is {user.getUserName()}");
        }
    }
}
