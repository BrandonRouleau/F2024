﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI {
    internal class Validate {
        public Person User { get; set; }

        public bool validateFirstName(string firstName) {
            if(string.IsNullOrWhiteSpace(firstName)) {
                return true;
            }
            return false;
        }

        public bool validateLastName(string lastName) {
            if (string.IsNullOrWhiteSpace(lastName)) {
                return true;
            }
            return false;
        }
    }
}
